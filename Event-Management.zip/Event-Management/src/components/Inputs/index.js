import { GenderSelection } from "./GenderSelection";
export default {
  GenderSelection,
};
