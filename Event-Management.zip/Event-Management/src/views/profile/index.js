export { UserProfile as default } from "./userProfile";
