export { CustTicket as default } from "./CustTicket";
