export { AdminList as default } from "./AdminList";
