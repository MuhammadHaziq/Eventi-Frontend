export {CustomerList as default} from "./CustomerList"
