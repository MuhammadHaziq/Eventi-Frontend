import React, { createContext } from "react";

const TestContext = createContext();

export default TestContext;
