const { default: TestContext } = require("./testContext")

import React "react"

const TestState  = ({children}) => {
  const lang = ["javaScript", "Node"]
  const [state, setState] = useState(lang[0])

  const toggeState = () => {

  }
  return (<TestContext.Provider>
        {children}
    </TestContext.Provider>)
}
