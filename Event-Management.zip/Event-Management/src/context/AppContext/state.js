export default {
  sidebarShow: true,
  unfoldable: false,
  toast: 0,
  currentUser: null,
  permissions: [],
};
