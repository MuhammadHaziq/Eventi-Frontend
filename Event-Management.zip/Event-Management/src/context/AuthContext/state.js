export default {
  auth: false,
  user: null,
  user_id: null,
};
