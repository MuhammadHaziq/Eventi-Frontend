// module.exports = {
//   semi: false,
//   trailingComma: "all",
//   singleQuote: true,
//   printWidth: 160,
//   tabWidth: 2
// };